<?php
$keys = array('tinfo','player1','player2','player3','player4','player5');
$msg = '';
$msg .= 'IP: '.$_SERVER['REMOTE_ADDR']."\n";
$msg .= 'Date: '.date("c")."\n\n";
foreach($keys as $k) { if(!isset($_POST[$k]) ) { die(); } $msg .= $_POST[$k]."\n\n";}
if ( !isset($_POST['avail']) ) { die(); }
if (!is_array($_POST['avail']) ) { die(); }
if ( count($_POST['avail']) > 9000 || count($_POST['avail']) == 0) { die("Availability incorrect."); }
$msg .= 'Available on the following: '."\n";
if ( count($_POST['avail']) < 20 ) { die("Please complete the 'Availability times' form."); }
foreach($_POST['avail'] as $dayt => $do)
{
if ( !is_string($do) ) { die(); }
	if ( strlen($dayt) != 11 ) { die("."); }
	$day = substr($dayt,0,8);
	$hour = substr($dayt,9,2);
	if ( !is_numeric($day) || !is_numeric($hour) ) { die("of course..."); }
	$msg .= $day." ".$hour.":00\n";
}
//echo "<pre>".$msg."</pre>";
if (mail('misc@woop.us','AC World Cup 2010 Registration',$msg))
{
	echo "<pre>Your registration has been sent. Expect a response soon. Thank you.
Make sure you allow all mail from @woop.us to reach you, in case it goes to your Spam folder.</pre>";
}
else {
	echo "<pre>There has been an error with the mail system! Your message was not received!</pre>";
}
?>
