<?php
  function uuid($prefix = '',$st=null)
  {
          if ( $st != null )
          {
                  $chars = md5($st);
                 }
                 else
                 {
    $chars = md5(uniqid(mt_rand(), true));
}
    $uuid  = substr($chars,0,8) . '-';
    $uuid .= substr($chars,8,4) . '-';
    $uuid .= substr($chars,12,4) . '-';
    $uuid .= substr($chars,16,4) . '-';
    $uuid .= substr($chars,20,12);
    return $prefix . $uuid;
  }

$views = array('index','matches','tree','ttree','teams','feed','registration','rules');
$d = simplexml_load_file("data.xml", 'SimpleXMLElement', LIBXML_NOCDATA);
if ( !isset($view) ) { if ( isset($_GET['view']) ) { $view = $_GET['view']; } else { die("No view given"); } }
if ( !in_array($view,$views) ) { die("View unknown"); }
$hf = true;
if ( $view == 'feed') { $hf = false; }

//var_dump($d->xpath('team[@id="FRA"]'));
if ( $hf ) {
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8">
<title>AssaultCube World Cup 2010</title>
<link href="/2010/res/style.css" type="text/css" rel="stylesheet">
<script type="text/javascript" src="/2010/res/script.js"></script>
<link href="/2010/feed.xml" type="application/atom+xml" rel="alternate">
</head>
<body>
<div id="main">
<h1><a href="/2010/"><span>AssaultCube World Cup 2010</span></a></h1>
<div id="centre">
<div id="irc"><p>IRC:
<a href="irc://irc.gamesurge.net/acwc">#acwc</a> (<a href="http://widget.mibbit.com/?server=irc.gamesurge.net&amp;channel=%23acwc" onclick="window.open('http://widget.mibbit.com/?server=irc.gamesurge.net&amp;channel=%23acwc','','width=999,height=555'); return false;">mibbit</a>).</p>
</div>
<div id="time">
<h3>Current time</h3>
<noscript>
<p>You need to enable JavaScript to see which time is the right one for you.</p>
</noscript>
<p class="time">Server time: <span id="servertime"></span><br>Your local time: <span id="localtime"></span></p>
<p class="s">Server time is the time that is on the server, and the local time is on your
computer. If something is inconsistent, just calculate the time difference
yourself (the timing script is experimental). Does not work with Internet
Explorer.</p>
</div>

<ul id="nav">
<li><a href="/2010/">Information</a></li>
<li><a href="/2010/tree/">Tournament tree</a></li>
<li><a href="/2010/teams/">Line-ups</a></li>
<li><a href="/2010/matches/">Match data</a></li>
<li><a href="/2010/registration/">Registration</a></li>
<li><a href="/2010/rules/">Rules</a></li>
</ul>
<div id="mb">
<?php } ?><?php if ( $view == 'index' )
{
	
	?>
	
	<?php if ( isset($d->side) )
	{
		?><?php } ?>
<p id="languages">

<a href="http://translate.google.com/translate?hl=en&sl=en&tl=pt&u=http%3A%2F%2Facwc.woop.us%2F2010%2F">Português</a>
 - <a href="http://translate.google.com/translate?hl=en&sl=en&tl=fr&u=http%3A%2F%2Facwc.woop.us%2F2010%2F">Français</a>
 - <a href="http://translate.google.com/translate?hl=en&sl=en&tl=de&u=http%3A%2F%2Facwc.woop.us%2F2010%2F">Deutsch</a>
 - <a href="http://translate.google.com/translate?hl=en&sl=en&tl=es&u=http%3A%2F%2Facwc.woop.us%2F2010%2F">Español</a>
 - <a href="http://translate.google.com/translate?hl=en&sl=en&tl=it&u=http%3A%2F%2Facwc.woop.us%2F2010%2F">Italiano</a>
</p>
<?php /*<h3 id="pwat">Players wanting a team <a href="#pwat" class="subber">#</a></h3>
<p>Make your request <a href="#nt">here</a> if you'd like to recruit a player. Make your request <a href="#nt">here</a> if you want a team.</p>
<ul id="pwt">
<?php foreach($d->wp as $player) {  ?>
<li><span class="ipl_<?php echo htmlspecialchars($player['country']); ?>"><?php echo htmlspecialchars($player['name']); ?></span></li>
<?php }  ?>
</ul>
<h3 id="twap">Teams wanting a player <a href="#twap" class="subber">#</a></h3>
<p>These player requests will be annulled on Wednesday, 14th.</p>
<ul id="twp">
<?php foreach($d->wc as $team) { ?>
<li><span class="ipl_<?php echo htmlspecialchars($team['country']); ?>"><?php echo htmlspecialchars($team['name']); ?></span><?php if ( isset($team['captain_country'],$team['captain']) ) { ?> (captain: <span class="ipl_<?php echo htmlspecialchars($team['captain_country']); ?>"><?php echo htmlspecialchars($team['captain']); ?></span>)<?php } ?></li>
<?php } ?>
</ul>*/ ?>
<p id="pat">Please attend the IRC channel: <a href="irc://irc.gamesurge.net/acwc">irc.gamesurge.net #acwc</a> (<a href="http://widget.mibbit.com/?server=irc.gamesurge.net&amp;channel=%23acwc" onclick='window.open("http://widget.mibbit.com/?server=irc.gamesurge.net&amp;channel=%23acwc","","width=999,height=555");return false'>mibbit, requires no installation</a>). If you want a client that can be installed, then you might want to consider <a href="http://www.kvirc.net/">KVIrc</a>, X-Chat (<a href="http://www.silverex.org/download/">Windows</a>, <a href="http://xchat.org/download/">other OS</a>), <a href="http://www.irssi.org/">irssi</a>, <a href="https://addons.mozilla.org/en-US/firefox/addon/16/">ChatZilla</a>.</p>
<h2>News<a href="/2010/feed.xml" class="feed"><img src="res/feed-icon-16x16.png" alt="Feed"></a></h2>
<div id="sideinfo">
<?php echo $d->side; ?>
</div><ul id="news"><?php
foreach($d->news as $news)
{
	$t = strtotime($news['date']);
	//var_dump($t);var_dump(time());
	//var_dump(date("r",$t)); var_dump(date("r",time()));
	 if ($t < time())
	 {
?>
<li<?php if (isset($news['id']) ) { ?> id="<?php echo htmlspecialchars($news['id']); ?>"<?php } ?>><?php
if ( !isset($news['by']) ) { $news->by = 'Admin'; }
?><span class="says"><span class="name"><?php echo htmlspecialchars($news['by']); ?></span> says: <?php if ( isset($news['title']) )
{
	?><span class="title"><?php if (isset($news['id']) ) { ?><a href="#<?php echo htmlspecialchars($news['id']); ?>" class="subber">#</a> <?php } ?><?php echo htmlspecialchars($news['title']); ?></span><?php } ?></span><div class="content"><?php echo $news->content; ?></div>
	<?php if (isset($news['date']) ) { ?> <address><?php echo date("r",strtotime($news['date'])); ?></address> <?php } ?>
	</li>
<?php
}
}
?>
</ul>
<?php
}
elseif ($view =='registration')
{
	?>
	<h2>Registration</h2>
<p><strong style="border-bottom:1px solid red">This is a serious competition. We expect commitment and rigour. We expect you to read, understand and agree to the rules. Your team <i>may</i> be refused on grounds of not meeting the rules or if we believe it is unfit to compete.</strong></p>
<p>If you are not generally known in the AC community, you must provide proof of your presence from previously.</p>
	<?php if ( true || !$d['registration'] ) { ?>
	<p>Registration is now closed.</p>
	<?php } else { ?>
	<div id="howtoregister">
	<h3>How to register?</h3>
	<p class="notice">Please read this carefully.</p>
	<p class="notice">As captain, you will be required to do all the inside communication.</p>
	<ol>
	<li>Find other three teammates you want to play with.</li>
	<li>Read the <a href="/2010/rules">rules</a>.</li>
	<li>Ask each of them for availability and come up with times your team can play.</li>
	<li>Complete the Team information form.</li>
	<li>Complete the Player information form.</li>
	<li>Complete the availability form. You can click on your timezone and others will disappear, to make it easier for you.</li>
	<li>Check everything thoroughly.</li>
	<li>Submit the registration.</li>
	<li>Wait for further information and be present on IRC.</li>
	</ol>
	</div>
<form method="post" enctype="multipart/form-data" action="/2010/register.do" id="register">
<h3>Team information</h3>
<textarea name="tinfo" rows="6" cols="40">Team name (if not based on a single country): 
(this is a country, not clan, competition)
Countries: 
Website: optional
Other information: optional</textarea>
<h3>Player information</h3>
<ul>
<li><textarea name="player1" rows="5" cols="40">Player 1 (you)
Nickname: 
E-mail: 
Country: 
Captain: yes</textarea></li>
<li><textarea name="player2" rows="4" cols="40">Player 2
Nickname: 
E-mail: 
Country: </textarea></li>
<li><textarea name="player3" rows="4" cols="40">Player 3
Nickname: 
E-mail: 
Country: </textarea></li>
<li><textarea name="player4" rows="5" cols="40">Player 4 (substitute)
Nickname: 
E-mail: 
Country: 
Substitute: yes</textarea></li>
<li><textarea name="player5" rows="5" cols="40">Player 5 (substitute)
Nickname: 
E-mail: 
Country: 
Substitute: yes</textarea></li>
</ul>
<h3>Team availability times</h3>
<p>Hint: press on your timezone to get rid of other timezones (and again to restore them). At least 20 hours of availability are expected.</p>
<!-- availability -->
<table id="avail">
<tr><th colspan="25"><span class="prev">Hour of previous day</span> <span class="next">Hour of next day</span></th></tr>
<tr><th>Day</th><th colspan="24">Time</th></tr>
<tr><th>UTC+0000:</th><th>00</th><th>01</th><th>02</th><th>03</th><th>04</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th><th>23</th></tr>
<tr class="tzl"><th>UTC-1000:</th><th class="prev">14</th><th class="prev">15</th><th class="prev">16</th><th class="prev">17</th><th class="prev">18</th><th class="prev">19</th><th class="prev">20</th><th class="prev">21</th><th class="prev">22</th><th class="prev">23</th><th>00</th><th>01</th><th>02</th><th>03</th><th>04</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th></tr>
<tr class="tzl"><th>UTC-0900:</th><th class="prev">15</th><th class="prev">16</th><th class="prev">17</th><th class="prev">18</th><th class="prev">19</th><th class="prev">20</th><th class="prev">21</th><th class="prev">22</th><th class="prev">23</th><th>00</th><th>01</th><th>02</th><th>03</th><th>04</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th></tr>
<tr class="tzl"><th>UTC-0800:</th><th class="prev">16</th><th class="prev">17</th><th class="prev">18</th><th class="prev">19</th><th class="prev">20</th><th class="prev">21</th><th class="prev">22</th><th class="prev">23</th><th>00</th><th>01</th><th>02</th><th>03</th><th>04</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th></tr>
<tr class="tzl"><th>UTC-0700:</th><th class="prev">17</th><th class="prev">18</th><th class="prev">19</th><th class="prev">20</th><th class="prev">21</th><th class="prev">22</th><th class="prev">23</th><th>00</th><th>01</th><th>02</th><th>03</th><th>04</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th></tr>
<tr class="tzl"><th>UTC-0600:</th><th class="prev">18</th><th class="prev">19</th><th class="prev">20</th><th class="prev">21</th><th class="prev">22</th><th class="prev">23</th><th>00</th><th>01</th><th>02</th><th>03</th><th>04</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th></tr>
<tr class="tzl"><th>UTC-0500:</th><th class="prev">19</th><th class="prev">20</th><th class="prev">21</th><th class="prev">22</th><th class="prev">23</th><th>00</th><th>01</th><th>02</th><th>03</th><th>04</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th></tr>
<tr class="tzl"><th>UTC-0400:</th><th class="prev">20</th><th class="prev">21</th><th class="prev">22</th><th class="prev">23</th><th>00</th><th>01</th><th>02</th><th>03</th><th>04</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th></tr>
<tr class="tzl"><th>UTC-0300:</th><th class="prev">21</th><th class="prev">22</th><th class="prev">23</th><th>00</th><th>01</th><th>02</th><th>03</th><th>04</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th></tr>
<tr class="tzl"><th>UTC-0200:</th><th class="prev">22</th><th class="prev">23</th><th>00</th><th>01</th><th>02</th><th>03</th><th>04</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th></tr>
<tr class="tzl"><th>UTC-0100:</th><th class="prev">23</th><th>00</th><th>01</th><th>02</th><th>03</th><th>04</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th></tr>
<tr class="tzl"><th>UTC+0000:</th><th>00</th><th>01</th><th>02</th><th>03</th><th>04</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th><th>23</th></tr>
<tr class="tzl"><th>UTC+0100:</th><th>01</th><th>02</th><th>03</th><th>04</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th><th>23</th><th class="next">00</th></tr>
<tr class="tzl"><th>UTC+0200:</th><th>02</th><th>03</th><th>04</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th><th>23</th><th class="next">00</th><th class="next">01</th></tr>
<tr class="tzl"><th>UTC+0300:</th><th>03</th><th>04</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th><th>23</th><th class="next">00</th><th class="next">01</th><th class="next">02</th></tr>
<tr class="tzl"><th>UTC+0400:</th><th>04</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th><th>23</th><th class="next">00</th><th class="next">01</th><th class="next">02</th><th class="next">03</th></tr>
<tr class="tzl"><th>UTC+0500:</th><th>05</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th><th>23</th><th class="next">00</th><th class="next">01</th><th class="next">02</th><th class="next">03</th><th class="next">04</th></tr>
<tr class="tzl"><th>UTC+0600:</th><th>06</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th><th>23</th><th class="next">00</th><th class="next">01</th><th class="next">02</th><th class="next">03</th><th class="next">04</th><th class="next">05</th></tr>
<tr class="tzl"><th>UTC+0700:</th><th>07</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th><th>23</th><th class="next">00</th><th class="next">01</th><th class="next">02</th><th class="next">03</th><th class="next">04</th><th class="next">05</th><th class="next">06</th></tr>
<tr class="tzl"><th>UTC+0800:</th><th>08</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th><th>23</th><th class="next">00</th><th class="next">01</th><th class="next">02</th><th class="next">03</th><th class="next">04</th><th class="next">05</th><th class="next">06</th><th class="next">07</th></tr>
<tr class="tzl"><th>UTC+0900:</th><th>09</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th><th>23</th><th class="next">00</th><th class="next">01</th><th class="next">02</th><th class="next">03</th><th class="next">04</th><th class="next">05</th><th class="next">06</th><th class="next">07</th><th class="next">08</th></tr>
<tr class="tzl"><th>UTC+1000:</th><th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th><th>23</th><th class="next">00</th><th class="next">01</th><th class="next">02</th><th class="next">03</th><th class="next">04</th><th class="next">05</th><th class="next">06</th><th class="next">07</th><th class="next">08</th><th class="next">09</th></tr>
<tr class="tzl"><th>UTC+1100:</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th><th>23</th><th class="next">00</th><th class="next">01</th><th class="next">02</th><th class="next">03</th><th class="next">04</th><th class="next">05</th><th class="next">06</th><th class="next">07</th><th class="next">08</th><th class="next">09</th><th class="next">10</th></tr>
<tr class="tzl"><th>UTC+1200:</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th><th>23</th><th class="next">00</th><th class="next">01</th><th class="next">02</th><th class="next">03</th><th class="next">04</th><th class="next">05</th><th class="next">06</th><th class="next">07</th><th class="next">08</th><th class="next">09</th><th class="next">10</th><th class="next">11</th></tr>
<tr class="tzl"><th>UTC+1300:</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th><th>23</th><th class="next">00</th><th class="next">01</th><th class="next">02</th><th class="next">03</th><th class="next">04</th><th class="next">05</th><th class="next">06</th><th class="next">07</th><th class="next">08</th><th class="next">09</th><th class="next">10</th><th class="next">11</th><th class="next">12</th></tr>
<tr>
<th>Fri, 16 Jul</th>
<td><input type="checkbox" name="avail[20100716_00]" value="1"></td><td><input type="checkbox" name="avail[20100716_01]" value="1"></td><td><input type="checkbox" name="avail[20100716_02]" value="1"></td><td><input type="checkbox" name="avail[20100716_03]" value="1"></td><td><input type="checkbox" name="avail[20100716_04]" value="1"></td><td><input type="checkbox" name="avail[20100716_05]" value="1"></td><td><input type="checkbox" name="avail[20100716_06]" value="1"></td><td><input type="checkbox" name="avail[20100716_07]" value="1"></td><td><input type="checkbox" name="avail[20100716_08]" value="1"></td><td><input type="checkbox" name="avail[20100716_09]" value="1"></td><td><input type="checkbox" name="avail[20100716_10]" value="1"></td><td><input type="checkbox" name="avail[20100716_11]" value="1"></td><td><input type="checkbox" name="avail[20100716_12]" value="1"></td><td><input type="checkbox" name="avail[20100716_13]" value="1"></td><td><input type="checkbox" name="avail[20100716_14]" value="1"></td><td><input type="checkbox" name="avail[20100716_15]" value="1"></td><td><input type="checkbox" name="avail[20100716_16]" value="1"></td><td><input type="checkbox" name="avail[20100716_17]" value="1"></td><td><input type="checkbox" name="avail[20100716_18]" value="1"></td><td><input type="checkbox" name="avail[20100716_19]" value="1"></td><td><input type="checkbox" name="avail[20100716_20]" value="1"></td><td><input type="checkbox" name="avail[20100716_21]" value="1"></td><td><input type="checkbox" name="avail[20100716_22]" value="1"></td><td><input type="checkbox" name="avail[20100716_23]" value="1"></td></tr>
<tr>
<th>Sat, 17 Jul</th>
<td><input type="checkbox" name="avail[20100717_00]" value="1"></td><td><input type="checkbox" name="avail[20100717_01]" value="1"></td><td><input type="checkbox" name="avail[20100717_02]" value="1"></td><td><input type="checkbox" name="avail[20100717_03]" value="1"></td><td><input type="checkbox" name="avail[20100717_04]" value="1"></td><td><input type="checkbox" name="avail[20100717_05]" value="1"></td><td><input type="checkbox" name="avail[20100717_06]" value="1"></td><td><input type="checkbox" name="avail[20100717_07]" value="1"></td><td><input type="checkbox" name="avail[20100717_08]" value="1"></td><td><input type="checkbox" name="avail[20100717_09]" value="1"></td><td><input type="checkbox" name="avail[20100717_10]" value="1"></td><td><input type="checkbox" name="avail[20100717_11]" value="1"></td><td><input type="checkbox" name="avail[20100717_12]" value="1"></td><td><input type="checkbox" name="avail[20100717_13]" value="1"></td><td><input type="checkbox" name="avail[20100717_14]" value="1"></td><td><input type="checkbox" name="avail[20100717_15]" value="1"></td><td><input type="checkbox" name="avail[20100717_16]" value="1"></td><td><input type="checkbox" name="avail[20100717_17]" value="1"></td><td><input type="checkbox" name="avail[20100717_18]" value="1"></td><td><input type="checkbox" name="avail[20100717_19]" value="1"></td><td><input type="checkbox" name="avail[20100717_20]" value="1"></td><td><input type="checkbox" name="avail[20100717_21]" value="1"></td><td><input type="checkbox" name="avail[20100717_22]" value="1"></td><td><input type="checkbox" name="avail[20100717_23]" value="1"></td></tr>
<tr>
<th>Sun, 18 Jul</th>
<td><input type="checkbox" name="avail[20100718_00]" value="1"></td><td><input type="checkbox" name="avail[20100718_01]" value="1"></td><td><input type="checkbox" name="avail[20100718_02]" value="1"></td><td><input type="checkbox" name="avail[20100718_03]" value="1"></td><td><input type="checkbox" name="avail[20100718_04]" value="1"></td><td><input type="checkbox" name="avail[20100718_05]" value="1"></td><td><input type="checkbox" name="avail[20100718_06]" value="1"></td><td><input type="checkbox" name="avail[20100718_07]" value="1"></td><td><input type="checkbox" name="avail[20100718_08]" value="1"></td><td><input type="checkbox" name="avail[20100718_09]" value="1"></td><td><input type="checkbox" name="avail[20100718_10]" value="1"></td><td><input type="checkbox" name="avail[20100718_11]" value="1"></td><td><input type="checkbox" name="avail[20100718_12]" value="1"></td><td><input type="checkbox" name="avail[20100718_13]" value="1"></td><td><input type="checkbox" name="avail[20100718_14]" value="1"></td><td><input type="checkbox" name="avail[20100718_15]" value="1"></td><td><input type="checkbox" name="avail[20100718_16]" value="1"></td><td><input type="checkbox" name="avail[20100718_17]" value="1"></td><td><input type="checkbox" name="avail[20100718_18]" value="1"></td><td><input type="checkbox" name="avail[20100718_19]" value="1"></td><td><input type="checkbox" name="avail[20100718_20]" value="1"></td><td><input type="checkbox" name="avail[20100718_21]" value="1"></td><td><input type="checkbox" name="avail[20100718_22]" value="1"></td><td><input type="checkbox" name="avail[20100718_23]" value="1"></td></tr>
<tr>
<th>Mon, 19 Jul</th>
<td><input type="checkbox" name="avail[20100719_00]" value="1"></td><td><input type="checkbox" name="avail[20100719_01]" value="1"></td><td><input type="checkbox" name="avail[20100719_02]" value="1"></td><td><input type="checkbox" name="avail[20100719_03]" value="1"></td><td><input type="checkbox" name="avail[20100719_04]" value="1"></td><td><input type="checkbox" name="avail[20100719_05]" value="1"></td><td><input type="checkbox" name="avail[20100719_06]" value="1"></td><td><input type="checkbox" name="avail[20100719_07]" value="1"></td><td><input type="checkbox" name="avail[20100719_08]" value="1"></td><td><input type="checkbox" name="avail[20100719_09]" value="1"></td><td><input type="checkbox" name="avail[20100719_10]" value="1"></td><td><input type="checkbox" name="avail[20100719_11]" value="1"></td><td><input type="checkbox" name="avail[20100719_12]" value="1"></td><td><input type="checkbox" name="avail[20100719_13]" value="1"></td><td><input type="checkbox" name="avail[20100719_14]" value="1"></td><td><input type="checkbox" name="avail[20100719_15]" value="1"></td><td><input type="checkbox" name="avail[20100719_16]" value="1"></td><td><input type="checkbox" name="avail[20100719_17]" value="1"></td><td><input type="checkbox" name="avail[20100719_18]" value="1"></td><td><input type="checkbox" name="avail[20100719_19]" value="1"></td><td><input type="checkbox" name="avail[20100719_20]" value="1"></td><td><input type="checkbox" name="avail[20100719_21]" value="1"></td><td><input type="checkbox" name="avail[20100719_22]" value="1"></td><td><input type="checkbox" name="avail[20100719_23]" value="1"></td></tr>
<tr>
<th>Tue, 20 Jul</th>
<td><input type="checkbox" name="avail[20100720_00]" value="1"></td><td><input type="checkbox" name="avail[20100720_01]" value="1"></td><td><input type="checkbox" name="avail[20100720_02]" value="1"></td><td><input type="checkbox" name="avail[20100720_03]" value="1"></td><td><input type="checkbox" name="avail[20100720_04]" value="1"></td><td><input type="checkbox" name="avail[20100720_05]" value="1"></td><td><input type="checkbox" name="avail[20100720_06]" value="1"></td><td><input type="checkbox" name="avail[20100720_07]" value="1"></td><td><input type="checkbox" name="avail[20100720_08]" value="1"></td><td><input type="checkbox" name="avail[20100720_09]" value="1"></td><td><input type="checkbox" name="avail[20100720_10]" value="1"></td><td><input type="checkbox" name="avail[20100720_11]" value="1"></td><td><input type="checkbox" name="avail[20100720_12]" value="1"></td><td><input type="checkbox" name="avail[20100720_13]" value="1"></td><td><input type="checkbox" name="avail[20100720_14]" value="1"></td><td><input type="checkbox" name="avail[20100720_15]" value="1"></td><td><input type="checkbox" name="avail[20100720_16]" value="1"></td><td><input type="checkbox" name="avail[20100720_17]" value="1"></td><td><input type="checkbox" name="avail[20100720_18]" value="1"></td><td><input type="checkbox" name="avail[20100720_19]" value="1"></td><td><input type="checkbox" name="avail[20100720_20]" value="1"></td><td><input type="checkbox" name="avail[20100720_21]" value="1"></td><td><input type="checkbox" name="avail[20100720_22]" value="1"></td><td><input type="checkbox" name="avail[20100720_23]" value="1"></td></tr>
<tr>
<th>Wed, 21 Jul</th>
<td><input type="checkbox" name="avail[20100721_00]" value="1"></td><td><input type="checkbox" name="avail[20100721_01]" value="1"></td><td><input type="checkbox" name="avail[20100721_02]" value="1"></td><td><input type="checkbox" name="avail[20100721_03]" value="1"></td><td><input type="checkbox" name="avail[20100721_04]" value="1"></td><td><input type="checkbox" name="avail[20100721_05]" value="1"></td><td><input type="checkbox" name="avail[20100721_06]" value="1"></td><td><input type="checkbox" name="avail[20100721_07]" value="1"></td><td><input type="checkbox" name="avail[20100721_08]" value="1"></td><td><input type="checkbox" name="avail[20100721_09]" value="1"></td><td><input type="checkbox" name="avail[20100721_10]" value="1"></td><td><input type="checkbox" name="avail[20100721_11]" value="1"></td><td><input type="checkbox" name="avail[20100721_12]" value="1"></td><td><input type="checkbox" name="avail[20100721_13]" value="1"></td><td><input type="checkbox" name="avail[20100721_14]" value="1"></td><td><input type="checkbox" name="avail[20100721_15]" value="1"></td><td><input type="checkbox" name="avail[20100721_16]" value="1"></td><td><input type="checkbox" name="avail[20100721_17]" value="1"></td><td><input type="checkbox" name="avail[20100721_18]" value="1"></td><td><input type="checkbox" name="avail[20100721_19]" value="1"></td><td><input type="checkbox" name="avail[20100721_20]" value="1"></td><td><input type="checkbox" name="avail[20100721_21]" value="1"></td><td><input type="checkbox" name="avail[20100721_22]" value="1"></td><td><input type="checkbox" name="avail[20100721_23]" value="1"></td></tr>
<tr>
<th>Thu, 22 Jul</th>
<td><input type="checkbox" name="avail[20100722_00]" value="1"></td><td><input type="checkbox" name="avail[20100722_01]" value="1"></td><td><input type="checkbox" name="avail[20100722_02]" value="1"></td><td><input type="checkbox" name="avail[20100722_03]" value="1"></td><td><input type="checkbox" name="avail[20100722_04]" value="1"></td><td><input type="checkbox" name="avail[20100722_05]" value="1"></td><td><input type="checkbox" name="avail[20100722_06]" value="1"></td><td><input type="checkbox" name="avail[20100722_07]" value="1"></td><td><input type="checkbox" name="avail[20100722_08]" value="1"></td><td><input type="checkbox" name="avail[20100722_09]" value="1"></td><td><input type="checkbox" name="avail[20100722_10]" value="1"></td><td><input type="checkbox" name="avail[20100722_11]" value="1"></td><td><input type="checkbox" name="avail[20100722_12]" value="1"></td><td><input type="checkbox" name="avail[20100722_13]" value="1"></td><td><input type="checkbox" name="avail[20100722_14]" value="1"></td><td><input type="checkbox" name="avail[20100722_15]" value="1"></td><td><input type="checkbox" name="avail[20100722_16]" value="1"></td><td><input type="checkbox" name="avail[20100722_17]" value="1"></td><td><input type="checkbox" name="avail[20100722_18]" value="1"></td><td><input type="checkbox" name="avail[20100722_19]" value="1"></td><td><input type="checkbox" name="avail[20100722_20]" value="1"></td><td><input type="checkbox" name="avail[20100722_21]" value="1"></td><td><input type="checkbox" name="avail[20100722_22]" value="1"></td><td><input type="checkbox" name="avail[20100722_23]" value="1"></td></tr>
<tr>
<th>Fri, 23 Jul</th>
<td><input type="checkbox" name="avail[20100723_00]" value="1"></td><td><input type="checkbox" name="avail[20100723_01]" value="1"></td><td><input type="checkbox" name="avail[20100723_02]" value="1"></td><td><input type="checkbox" name="avail[20100723_03]" value="1"></td><td><input type="checkbox" name="avail[20100723_04]" value="1"></td><td><input type="checkbox" name="avail[20100723_05]" value="1"></td><td><input type="checkbox" name="avail[20100723_06]" value="1"></td><td><input type="checkbox" name="avail[20100723_07]" value="1"></td><td><input type="checkbox" name="avail[20100723_08]" value="1"></td><td><input type="checkbox" name="avail[20100723_09]" value="1"></td><td><input type="checkbox" name="avail[20100723_10]" value="1"></td><td><input type="checkbox" name="avail[20100723_11]" value="1"></td><td><input type="checkbox" name="avail[20100723_12]" value="1"></td><td><input type="checkbox" name="avail[20100723_13]" value="1"></td><td><input type="checkbox" name="avail[20100723_14]" value="1"></td><td><input type="checkbox" name="avail[20100723_15]" value="1"></td><td><input type="checkbox" name="avail[20100723_16]" value="1"></td><td><input type="checkbox" name="avail[20100723_17]" value="1"></td><td><input type="checkbox" name="avail[20100723_18]" value="1"></td><td><input type="checkbox" name="avail[20100723_19]" value="1"></td><td><input type="checkbox" name="avail[20100723_20]" value="1"></td><td><input type="checkbox" name="avail[20100723_21]" value="1"></td><td><input type="checkbox" name="avail[20100723_22]" value="1"></td><td><input type="checkbox" name="avail[20100723_23]" value="1"></td></tr>
<tr>
<th>Sat, 24 Jul</th>
<td><input type="checkbox" name="avail[20100724_00]" value="1"></td><td><input type="checkbox" name="avail[20100724_01]" value="1"></td><td><input type="checkbox" name="avail[20100724_02]" value="1"></td><td><input type="checkbox" name="avail[20100724_03]" value="1"></td><td><input type="checkbox" name="avail[20100724_04]" value="1"></td><td><input type="checkbox" name="avail[20100724_05]" value="1"></td><td><input type="checkbox" name="avail[20100724_06]" value="1"></td><td><input type="checkbox" name="avail[20100724_07]" value="1"></td><td><input type="checkbox" name="avail[20100724_08]" value="1"></td><td><input type="checkbox" name="avail[20100724_09]" value="1"></td><td><input type="checkbox" name="avail[20100724_10]" value="1"></td><td><input type="checkbox" name="avail[20100724_11]" value="1"></td><td><input type="checkbox" name="avail[20100724_12]" value="1"></td><td><input type="checkbox" name="avail[20100724_13]" value="1"></td><td><input type="checkbox" name="avail[20100724_14]" value="1"></td><td><input type="checkbox" name="avail[20100724_15]" value="1"></td><td><input type="checkbox" name="avail[20100724_16]" value="1"></td><td><input type="checkbox" name="avail[20100724_17]" value="1"></td><td><input type="checkbox" name="avail[20100724_18]" value="1"></td><td><input type="checkbox" name="avail[20100724_19]" value="1"></td><td><input type="checkbox" name="avail[20100724_20]" value="1"></td><td><input type="checkbox" name="avail[20100724_21]" value="1"></td><td><input type="checkbox" name="avail[20100724_22]" value="1"></td><td><input type="checkbox" name="avail[20100724_23]" value="1"></td></tr>
<tr>
<th>Sun, 25 Jul</th>
<td><input type="checkbox" name="avail[20100725_00]" value="1"></td><td><input type="checkbox" name="avail[20100725_01]" value="1"></td><td><input type="checkbox" name="avail[20100725_02]" value="1"></td><td><input type="checkbox" name="avail[20100725_03]" value="1"></td><td><input type="checkbox" name="avail[20100725_04]" value="1"></td><td><input type="checkbox" name="avail[20100725_05]" value="1"></td><td><input type="checkbox" name="avail[20100725_06]" value="1"></td><td><input type="checkbox" name="avail[20100725_07]" value="1"></td><td><input type="checkbox" name="avail[20100725_08]" value="1"></td><td><input type="checkbox" name="avail[20100725_09]" value="1"></td><td><input type="checkbox" name="avail[20100725_10]" value="1"></td><td><input type="checkbox" name="avail[20100725_11]" value="1"></td><td><input type="checkbox" name="avail[20100725_12]" value="1"></td><td><input type="checkbox" name="avail[20100725_13]" value="1"></td><td><input type="checkbox" name="avail[20100725_14]" value="1"></td><td><input type="checkbox" name="avail[20100725_15]" value="1"></td><td><input type="checkbox" name="avail[20100725_16]" value="1"></td><td><input type="checkbox" name="avail[20100725_17]" value="1"></td><td><input type="checkbox" name="avail[20100725_18]" value="1"></td><td><input type="checkbox" name="avail[20100725_19]" value="1"></td><td><input type="checkbox" name="avail[20100725_20]" value="1"></td><td><input type="checkbox" name="avail[20100725_21]" value="1"></td><td><input type="checkbox" name="avail[20100725_22]" value="1"></td><td><input type="checkbox" name="avail[20100725_23]" value="1"></td></tr>
<tr>
<th>Mon, 26 Jul</th>
<td><input type="checkbox" name="avail[20100726_00]" value="1"></td><td><input type="checkbox" name="avail[20100726_01]" value="1"></td><td><input type="checkbox" name="avail[20100726_02]" value="1"></td><td><input type="checkbox" name="avail[20100726_03]" value="1"></td><td><input type="checkbox" name="avail[20100726_04]" value="1"></td><td><input type="checkbox" name="avail[20100726_05]" value="1"></td><td><input type="checkbox" name="avail[20100726_06]" value="1"></td><td><input type="checkbox" name="avail[20100726_07]" value="1"></td><td><input type="checkbox" name="avail[20100726_08]" value="1"></td><td><input type="checkbox" name="avail[20100726_09]" value="1"></td><td><input type="checkbox" name="avail[20100726_10]" value="1"></td><td><input type="checkbox" name="avail[20100726_11]" value="1"></td><td><input type="checkbox" name="avail[20100726_12]" value="1"></td><td><input type="checkbox" name="avail[20100726_13]" value="1"></td><td><input type="checkbox" name="avail[20100726_14]" value="1"></td><td><input type="checkbox" name="avail[20100726_15]" value="1"></td><td><input type="checkbox" name="avail[20100726_16]" value="1"></td><td><input type="checkbox" name="avail[20100726_17]" value="1"></td><td><input type="checkbox" name="avail[20100726_18]" value="1"></td><td><input type="checkbox" name="avail[20100726_19]" value="1"></td><td><input type="checkbox" name="avail[20100726_20]" value="1"></td><td><input type="checkbox" name="avail[20100726_21]" value="1"></td><td><input type="checkbox" name="avail[20100726_22]" value="1"></td><td><input type="checkbox" name="avail[20100726_23]" value="1"></td></tr>
<tr>
<th>Tue, 27 Jul</th>
<td><input type="checkbox" name="avail[20100727_00]" value="1"></td><td><input type="checkbox" name="avail[20100727_01]" value="1"></td><td><input type="checkbox" name="avail[20100727_02]" value="1"></td><td><input type="checkbox" name="avail[20100727_03]" value="1"></td><td><input type="checkbox" name="avail[20100727_04]" value="1"></td><td><input type="checkbox" name="avail[20100727_05]" value="1"></td><td><input type="checkbox" name="avail[20100727_06]" value="1"></td><td><input type="checkbox" name="avail[20100727_07]" value="1"></td><td><input type="checkbox" name="avail[20100727_08]" value="1"></td><td><input type="checkbox" name="avail[20100727_09]" value="1"></td><td><input type="checkbox" name="avail[20100727_10]" value="1"></td><td><input type="checkbox" name="avail[20100727_11]" value="1"></td><td><input type="checkbox" name="avail[20100727_12]" value="1"></td><td><input type="checkbox" name="avail[20100727_13]" value="1"></td><td><input type="checkbox" name="avail[20100727_14]" value="1"></td><td><input type="checkbox" name="avail[20100727_15]" value="1"></td><td><input type="checkbox" name="avail[20100727_16]" value="1"></td><td><input type="checkbox" name="avail[20100727_17]" value="1"></td><td><input type="checkbox" name="avail[20100727_18]" value="1"></td><td><input type="checkbox" name="avail[20100727_19]" value="1"></td><td><input type="checkbox" name="avail[20100727_20]" value="1"></td><td><input type="checkbox" name="avail[20100727_21]" value="1"></td><td><input type="checkbox" name="avail[20100727_22]" value="1"></td><td><input type="checkbox" name="avail[20100727_23]" value="1"></td></tr>
<tr>
<th>Wed, 28 Jul</th>
<td><input type="checkbox" name="avail[20100728_00]" value="1"></td><td><input type="checkbox" name="avail[20100728_01]" value="1"></td><td><input type="checkbox" name="avail[20100728_02]" value="1"></td><td><input type="checkbox" name="avail[20100728_03]" value="1"></td><td><input type="checkbox" name="avail[20100728_04]" value="1"></td><td><input type="checkbox" name="avail[20100728_05]" value="1"></td><td><input type="checkbox" name="avail[20100728_06]" value="1"></td><td><input type="checkbox" name="avail[20100728_07]" value="1"></td><td><input type="checkbox" name="avail[20100728_08]" value="1"></td><td><input type="checkbox" name="avail[20100728_09]" value="1"></td><td><input type="checkbox" name="avail[20100728_10]" value="1"></td><td><input type="checkbox" name="avail[20100728_11]" value="1"></td><td><input type="checkbox" name="avail[20100728_12]" value="1"></td><td><input type="checkbox" name="avail[20100728_13]" value="1"></td><td><input type="checkbox" name="avail[20100728_14]" value="1"></td><td><input type="checkbox" name="avail[20100728_15]" value="1"></td><td><input type="checkbox" name="avail[20100728_16]" value="1"></td><td><input type="checkbox" name="avail[20100728_17]" value="1"></td><td><input type="checkbox" name="avail[20100728_18]" value="1"></td><td><input type="checkbox" name="avail[20100728_19]" value="1"></td><td><input type="checkbox" name="avail[20100728_20]" value="1"></td><td><input type="checkbox" name="avail[20100728_21]" value="1"></td><td><input type="checkbox" name="avail[20100728_22]" value="1"></td><td><input type="checkbox" name="avail[20100728_23]" value="1"></td></tr>
<tr>
<th>Thu, 29 Jul</th>
<td><input type="checkbox" name="avail[20100729_00]" value="1"></td><td><input type="checkbox" name="avail[20100729_01]" value="1"></td><td><input type="checkbox" name="avail[20100729_02]" value="1"></td><td><input type="checkbox" name="avail[20100729_03]" value="1"></td><td><input type="checkbox" name="avail[20100729_04]" value="1"></td><td><input type="checkbox" name="avail[20100729_05]" value="1"></td><td><input type="checkbox" name="avail[20100729_06]" value="1"></td><td><input type="checkbox" name="avail[20100729_07]" value="1"></td><td><input type="checkbox" name="avail[20100729_08]" value="1"></td><td><input type="checkbox" name="avail[20100729_09]" value="1"></td><td><input type="checkbox" name="avail[20100729_10]" value="1"></td><td><input type="checkbox" name="avail[20100729_11]" value="1"></td><td><input type="checkbox" name="avail[20100729_12]" value="1"></td><td><input type="checkbox" name="avail[20100729_13]" value="1"></td><td><input type="checkbox" name="avail[20100729_14]" value="1"></td><td><input type="checkbox" name="avail[20100729_15]" value="1"></td><td><input type="checkbox" name="avail[20100729_16]" value="1"></td><td><input type="checkbox" name="avail[20100729_17]" value="1"></td><td><input type="checkbox" name="avail[20100729_18]" value="1"></td><td><input type="checkbox" name="avail[20100729_19]" value="1"></td><td><input type="checkbox" name="avail[20100729_20]" value="1"></td><td><input type="checkbox" name="avail[20100729_21]" value="1"></td><td><input type="checkbox" name="avail[20100729_22]" value="1"></td><td><input type="checkbox" name="avail[20100729_23]" value="1"></td></tr>
<tr>
<th>Fri, 30 Jul</th>
<td><input type="checkbox" name="avail[20100730_00]" value="1"></td><td><input type="checkbox" name="avail[20100730_01]" value="1"></td><td><input type="checkbox" name="avail[20100730_02]" value="1"></td><td><input type="checkbox" name="avail[20100730_03]" value="1"></td><td><input type="checkbox" name="avail[20100730_04]" value="1"></td><td><input type="checkbox" name="avail[20100730_05]" value="1"></td><td><input type="checkbox" name="avail[20100730_06]" value="1"></td><td><input type="checkbox" name="avail[20100730_07]" value="1"></td><td><input type="checkbox" name="avail[20100730_08]" value="1"></td><td><input type="checkbox" name="avail[20100730_09]" value="1"></td><td><input type="checkbox" name="avail[20100730_10]" value="1"></td><td><input type="checkbox" name="avail[20100730_11]" value="1"></td><td><input type="checkbox" name="avail[20100730_12]" value="1"></td><td><input type="checkbox" name="avail[20100730_13]" value="1"></td><td><input type="checkbox" name="avail[20100730_14]" value="1"></td><td><input type="checkbox" name="avail[20100730_15]" value="1"></td><td><input type="checkbox" name="avail[20100730_16]" value="1"></td><td><input type="checkbox" name="avail[20100730_17]" value="1"></td><td><input type="checkbox" name="avail[20100730_18]" value="1"></td><td><input type="checkbox" name="avail[20100730_19]" value="1"></td><td><input type="checkbox" name="avail[20100730_20]" value="1"></td><td><input type="checkbox" name="avail[20100730_21]" value="1"></td><td><input type="checkbox" name="avail[20100730_22]" value="1"></td><td><input type="checkbox" name="avail[20100730_23]" value="1"></td></tr>
</table>

<!-- availability -->
<input type="submit" value="Submit registration">
</form>
	<?php }
}
elseif ( $view == 'tree' )
{
	require_once("tree.inc.php");
}
elseif ( $view == 'tree' )
{
	?>
	<h2>Tournament tree</h2>
	<p>The tournament tree is not available as of yet.</p>
	<?php
}
elseif ( $view == 'rules' )
{
	?>
	<h2>Rules of competition</h2>
	<?php if ( isset($d->rules) ) { echo $d->rules; } else { ?><p>Rules are not available.</p>
	<?php }
}
elseif ( $view == 'matches' )
{
	?>
	<h2>Match data</h2>
	<!--<p class="imp">Unless you've been e-mailed, these times are only an indication.</p>-->
	<ul id="matches">
	<?php
	if ( count($d->match) == 0 )
	{?><p>No matches have been published yet.</p><?php
	}
	foreach($d->match as $match)
	{
		$teams = array();
		$t = $d->xpath('team[@id="'.$match['team1'].'"]');
		if ( !empty($t) ) { $teams[] = $t[0]; }
		$t = $d->xpath('team[@id="'.$match['team2'].'"]');
		if ( !empty($t) ) { $teams[] = $t[0]; }
		unset($winner);
		if (isset( $match['winner']) && count($teams) == 2 ) {
			$t = $d->xpath('team[@id="'.((string)$match['winner']).'"]');
			if ( !empty($t) ) { $winner = $t[0]; } }
		?><li class="match<?php if ($match['unconfirmed'] ) { ?> unconfirmed<?php } ?><?php if ($match['incomplete'] ) { ?> incomplete<?php } ?>"<?php if (isset($match['id']) ) { ?> id="m<?php echo $match['id']; ?>"<?php } ?>>
	<dl class="match">
		<dt><a href="#m<?php echo $match['id']; ?>" class="matchid">#<?php echo $match['id']; ?></a><?php
		$first = true;
		foreach($teams as $team) {
		if ( $first ) { $first = false; } else { echo " vs. "; }
		?>
		<span><a href="teams#t_<?php echo $team['id']; ?>" class="clink country<?php if (isset($match['winner'])) { echo ((string)$winner['id'] == (string)$team['id']) ? " winner": " loser"; } ?> ipl_<?php
		echo $team['flag']; ?>"><?php echo htmlspecialchars($team['name']); ?></a></span>
		<?php } 
		if ( count($teams) == 1 ) { ?> vs. ?<?php }
		?>
		<!--<a href="#m<?php echo $match['id']; ?>" class="subber">#</a>--></dt>
		<?php if (isset($match['time'],$match['day'])) { ?><dd>Date/time: <?php echo $match['day']; ?>, <span class="dc"><?php echo $match['time']; ?></span></dd><?php } ?>
		<?php if ( isset($winner) ) { ?>
			<dd><span class="country ipl_<?php
		echo $winner['flag']; ?>"><?php echo htmlspecialchars($winner['name']); ?></span> wins<?php if ( isset($match['wscore']) ) { echo " ".$match['wscore']; } ?>.</dd>
			<?php } ?>
		<?php
		$gid = 0;
			$ggz = 'data/'.str_pad((string)$match['id'],2,'0',STR_PAD_LEFT).'_'.str_pad((string)$teams[0]['id'],3,'_',STR_PAD_RIGHT).
					'_vs_'.str_pad((string)$teams[1]['id'],3,'_',STR_PAD_RIGHT);
		foreach($match->game as $gi=> $game)
		{
			$gid++;
			if ( isset($game->screenshot) && empty($game->screenshot) )
			{
				$game->screenshot = $ggz.'_game'.$gid.'.png';
			}
			if ( isset($game->demo) && empty($game->demo) )
			{
				$game->demo = $ggz.'_game'.$gid.'.dmo';
			}
			if (isset($game['mode'],$game['map'],$game['winner'],$game['score']) )
			{
				$winner = null;
				if (count($teams) == 2 ) {$wid = ((string)$game['winner'] == (string)$match['team1']) ? 0 : 1;
				$gwinner = $teams[$wid]; $loser = $teams[1-$wid]; }
			?>
			<dd>
			<span class="map"><?php echo htmlspecialchars($game['mode']." @ ".$game['map']); ?></span> - 
			<span class="ipl_<?php echo $gwinner['flag']; ?>"><span class="winner"><?php
			 echo htmlspecialchars($gwinner['name']); ?> wins <?php echo $game['score']; ?>.</span></span>
			 <?php if ( isset($game->screenshot) ) { ?>
			 <span class="screenshot"><a href="<?php echo htmlspecialchars($game->screenshot); ?>">screenshot</a></span>
			 <?php } ?>
			 <?php if ( isset($game->demo) ) { ?>
			 <span class="demo"><a href="<?php echo htmlspecialchars($game->demo); ?>">demo</a></span>
			 <?php } ?>
			</dd>
			<?php
			}
		}
		$c = count($match->live) == 1;
		$xx = -1;
		foreach($match->live as $live)
		{$xx++;
			$nam = ($c ? '' : ($xx+1));
			?><dd class="live"><a href="<?php $ls = (string)$live; echo empty($ls) ? $ggz.'_live'.$nam.'.ogg' : $ls; ?>"><?php
			echo ($live['title'] ? htmlspecialchars($live['title']) : 'Live commentary'.(($nam == '') ? '' : ' #'.$nam)); ?></a></dd><?php } 
		if ( isset($match->comment) ) { foreach($match->comment as $comment) { ?><dd class="comment"><?php echo $comment; ?></dd><?php }  }
		?>
		
	</dl></li>
		<?php
	}
	?>
	</ul>
	<?php
}
elseif ( $view == 'teams' )
{
	?>
	<h2>Line-ups</h2>
	<ul id="tlist">
	<?php foreach($d->team as $team) { ?>
	<li><a href="#t_<?php echo $team['id']; ?>" class="ipl_<?php echo $team['flag']; ?>"><?php echo htmlspecialchars($team['name']); ?></a></li>
	<?php } ?>
	</ul>
	<ul id="teams">
	<?php 
	
	if ( count($d->team) == 0 )
	{?><p>No teams have been registered yet.</p><?php
	}
	foreach($d->team as $team) { 
		
		?>
	<li id="t_<?php echo htmlspecialchars($team['id']); ?>"><dl>
<dt><span class="pl_<?php echo $team['flag']; ?>"><?php
 echo htmlspecialchars($team['name']); ?> (<?php 
 echo isset($team['tz']) ? $team['tz'] : 'Unknown TZ'; ?>)<?php 
 if (isset($team['url'])){ ?> (<a href="<?php
  echo htmlspecialchars($team['url']); ?>">website</a>)<?php } ?><?php if ( isset($team['irc']) ) {
	  
	  ?>
	   (<a href="<?php echo htmlspecialchars($team['irc']); ?>"><?php 
	   if ( !preg_match('/\/([^\/]+)$/',$team['irc'],$m) ) { echo htmlspecialchars($team['irc']); }
	   else { echo '#'.htmlspecialchars($m[1]); } ?></a>)
	  <?php
	  } ?></span></dt>
<?php foreach($team->player as $player) { ?><dd><span<?php if ( isset($player['flag']) ) { ?> class="ipl_<?php echo htmlspecialchars($player['flag']); ?>"<?php } ?>><?php 

echo htmlspecialchars($player['name']); 

?></span><?php 
$pg = array();
if ( isset($player['captain']) ) { $pg[] = 'captain'; }
if ( isset($player['sub']) ) { $pg[] = 'sub'; }
if ( count($pg) > 0 )
{
echo " (".implode(", ",$pg).")";
}
?></dd><?php } ?><?php if ( false && isset($team['mixed']) ) { ?><dd>This team is mixed, so will be officially listed on Friday.</dd><?php } ?>
</dl></li>
	
	<?php } ?>
	</ul>
	
	<?php
}
elseif ( $view == 'feed' )
{
	
	header("Content-type: application/xml");
	
	$pt = 0;
	foreach($d->news as $news) { if ( isset($news['date']) ) { $t = strtotime($news['date']); if ($t > $pt && $t < time()) { $pt = $t; } } }
	// feed
	echo '<'.'?xml version="1.0" encoding="utf-8"?'.">\n";
	?><feed xmlns="http://www.w3.org/2005/Atom">
 
 <title>ACWC News</title>
 <link href="http://acwc.woop.us/2010/feed.xml" rel="self"/>
 <link href="http://acwc.woop.us/2010/"/>
 <updated><?php echo date('c',$pt); ?></updated>
 <id>urn:uuid:ea24c681-ccfb-c74a-022c-2df26bfa2e0a</id>
 
 <?php foreach($d->news as $news) { 
	 $t = strtotime($news['date']);
	 if ( isset($news['id'],$news['title'],$news->content,$news['date']) && $t < time()) {?>
 <entry>

    <title><?php echo htmlspecialchars($news['title']); ?></title>
   <link href="http://acwc.woop.us/2010/#<?php echo $news['id']; ?>"/>
   <id>urn:uuid:<?php echo uuid('',$news['id']); ?></id>
	<author>
		<name><?php echo htmlspecialchars(isset($news['by']) ? $news['by'] : 'Admin'); ?></name>
	</author>
   <updated><?php echo date('c',$t); ?></updated>

   <summary type="html"><?php echo htmlspecialchars($news->content); ?></summary>
 </entry>
<?php } else {  }} ?>
</feed>
	<?php
	// feed
}
?>

<?php if ( $hf ) { ?>
<div class="clear"></div>
</div>
</div>
<div id="footer"><p>Drakas of the <a href="http://woop.us/">Woop Clan</a> &amp; the <a href="http://hi-skill.us/">HI-SKILL ladder</a>.</p></div>
</div>
</body>
</html><?php } ?>
