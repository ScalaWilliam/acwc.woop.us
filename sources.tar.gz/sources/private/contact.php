<?php
$msg = '';
$msg .= 'IP: '.$_SERVER['REMOTE_ADDR']."\n";
$msg .= 'Date: '.date("c")."\n\n";
if ( !isset($_POST['content']) ) { die(); }
$msg .= $_POST['content'];

if (mail('misc@woop.us','AC World Cup 2010 Query',$msg))
{
	echo "<pre>Your query has been sent. Expect a response soon. Thank you.
Make sure you allow all mail from @woop.us to reach you, in case it goes to your Spam folder.</pre>";
}
else {
	echo "<pre>There has been an error with the mail system! Your message was not received!</pre>";
}
?>
