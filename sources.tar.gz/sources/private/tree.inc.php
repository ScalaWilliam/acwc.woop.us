<?php
ini_set("display_errors","On");
$matches = array();
foreach($d->match as $match)
{
	$id = (int)$match['id'];
	$matches[$id] = $match;
}
$teams = array();
foreach($d->team as $team) { $teams[(string)$team['id']] = $team; }
function match_fighter($mid, $tn)
{
	$m = match_get($mid);
	global $teams;
	if ( $mid == 18 && $tn == 2 ) { $em = 'Lower bracket winner'; } else {$em = ''; }
	if ( !isset($m) ) { return $em; }
	if ( !($tn === 1 || $tn === 2) ) { return $em; }
	$tn = 'team'.$tn;
	if ( empty($m[$tn]) ) { return $em; }
	$teamid = (string)$m[$tn];
	
	if ( !isset($teams[$teamid]) ) { return ''.$teamid.''; }
	$team = $teams[$teamid];
	return team_code($team);
}
function team_code($team)
{
	return '<a href="/2010/teams/#t_'.$team['id'].'" class="pl_'.$team['flag'].'">'.htmlspecialchars($team['name']).'</a>';
};
function winner()
{
	return match_winner(19);
}
function match_winner($mid)
{
	$m = match_get($mid);
	if ( !$m )
	{
		return '';
	}
	if ( !$m['winner'] )
	{
		return '';
	}
	$t = team_get($m['winner']);
	if ( !$t )
	{
		return '';
	}
	return team_code($t);
}
function match_get($mid)
{
	global $matches;
	if ( !isset($matches[(int)$mid]) ) { return false; }
	return $matches[(int)$mid];
};
function team_get($tid)
{
	global $teams;
	if ( !isset($teams[(string)$tid]) ) { return false; }
	return $teams[(string)$tid];
};
function match_info($mid)
{
	$m = match_get($mid);
	if ( !$m ) { return 'Match info'; }
	if ($m['inactive'] || !$m['time']) { return 'Match info'; }
	return '<a href="/2010/matches/#m'.$m['id'].'">Match info</a>';
}
?>
<h2>Tournament tree</h2>

<table border="0" cellpadding="0" cellspacing="0" class="ttree">
  <caption>Main bracket</caption>
  <col width="150">
  <col width="30">
  <col width="150">
  <col width="30">
  <col width="150">
  <col width="30">
  <col width="150">
  <col width="30">
  <col width="150">
  <tbody>
    <tr>
      <th>Round 1</th>
      <th></th>
      <th>Round 2</th>
      <th></th>
      <th>Round 3</th>
      <th></th>
      <th>Final</th>
      <th></th>
      <th>Winner</th>
    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(1,1); ?>
      </td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline matchdata"><?php echo match_info(1); ?>
      </td>
      <td class="goto"></td>
      <td class="rline fighter"><?php echo match_fighter(13,1); ?>
      </td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(1,2); ?>
      </td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td class="rline matchdata"><?php echo match_info(13); ?>
      </td>
      <td class="goto"></td>
      <td class="rline fighter"><?php echo match_fighter(17,1); ?>
      </td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(2,1); ?>
      </td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline matchdata"><?php echo match_info(2); ?>
      </td>
      <td class="goto"></td>
      <td class="rline fighter"><?php echo match_fighter(13,2); ?>
      </td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(2,2); ?>
      </td>
      <td></td>
      <td></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td class="rline matchdata"><?php echo match_info(17); ?>
      </td>
      <td class="goto"></td>
      <td class="fighter  finalist rline"><?php echo match_fighter(19,1); ?>
      </td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(3,1); ?>
      </td>
      <td></td>
      <td></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline matchdata"><?php echo match_info(3); ?>
      </td>
      <td class="goto"></td>
      <td class="rline fighter"><?php echo match_fighter(14,1); ?>
      </td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(3,2); ?>
      </td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td class="rline matchdata"><?php echo match_info(14); ?>
      </td>
      <td class="goto"></td>
      <td class="rline fighter"><?php echo match_fighter(17,2); ?>
      </td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(4,1); ?>
      </td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline matchdata"><?php echo match_info(4); ?>
      </td>
      <td class="goto"></td>
      <td class="rline fighter"><?php echo match_fighter(14,2); ?>
      </td>
      <td></td>
      <td></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(4,2); ?>
      </td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td class="rline matchdata"><?php echo match_info(19); ?>
      </td>
      <td class="goto"></td>
      <td class="fighter  winner"><?php echo winner(); ?>      </td>
    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(5,1); ?>
      </td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline matchdata"><?php echo match_info(5); ?>
      </td>
      <td class="goto"></td>
      <td class="rline fighter"><?php echo match_fighter(15,1); ?>
      </td>
      <td></td>
      <td></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(5,2); ?>
      </td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td class="rline matchdata"><?php echo match_info(15); ?>
      </td>
      <td class="goto"></td>
      <td class="rline fighter "><?php echo match_fighter(18,1); ?>
      </td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(6,1); ?>
      </td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline matchdata"><?php echo match_info(6); ?>
      </td>
      <td class="goto"></td>
      <td class="rline fighter"><?php echo match_fighter(15,2); ?>
      </td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(6,2); ?>
      </td>
      <td></td>
      <td></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td class="rline matchdata"><?php echo match_info(18); ?>
      </td>
      <td class="goto"></td>
      <td class="fighter finalist rline"><?php echo match_fighter(19,2); ?>
      </td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <!--<td class="goto"></td>-->
      <td></td>
      <td class="rline fighter "><?php echo match_fighter(18,2); ?>
      </td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>
      </td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  </tbody>
</table>

<table border="0" cellpadding="0" cellspacing="0" class="ttree">
  <caption>Third place</caption>
  <col width="150"></col>
  <col width="50"></col>
  <col width="150"></col>
  <tbody>
  <tr>
  <td class="rline fighter"><?php echo match_fighter(23,1); ?></td>
  <td></td>
  <td></td>
  </tr>
  <tr>
  <td class="rline matchdata"><?php echo match_info(23); ?></td>
  <td class="goto"></td>
  <td class="fighter"><?php echo match_winner(23); ?></td>
  </tr>
  <tr>
  <td class="rline fighter"><?php echo match_fighter(23,2); ?></td>
  <td></td>
  <td></td>
  </tr>
  
  </tbody>
<table border="0" cellpadding="0" cellspacing="0" class="ttree">
  <caption>Lower bracket</caption>
  <col width="150"></col>
  <col width="50"></col>
  <col width="150"></col>
  <col width="50"></col>
  <col width="150"></col>

  <col width="50"></col>
  <col width="150"></col>
  <tbody>
    <tr>
      <th>Pre-elimination</th>
      <th></th>
      <th>Round 1</th>
      <th></th>

      <th>Round 2</th>
      <th></th>
      <th>Round 3</th>
    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(7,1); ?></td>
      <td></td>

      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline matchdata"><?php echo match_info(7);?></td>

      <td class="goto"></td>
      <td class="rline fighter"><?php echo match_fighter(20,1); ?></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>

      <td class="rline fighter"><?php echo match_fighter(7,2); ?></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>

    <tr>
      <td></td>
      <td></td>
      <td class="rline matchdata"><?php echo match_info(20);?></td>
      <td class="goto"></td>
      <td class="rline fighter "><?php echo match_fighter(22,1); ?></td>
      <td></td>
      <td></td>

    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(8,1); ?></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td class="rline"></td>
      <td></td>

      <td></td>
    </tr>
    <tr>
      <td class="rline matchdata"><?php echo match_info(8);?></td>
      <td class="goto"></td>
      <td class="rline fighter"><?php echo match_fighter(20,2); ?></td>
      <td></td>
      <td class="rline"></td>

      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(8,2); ?></td>
      <td></td>
      <td></td>
      <td></td>

      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td></td>

      <td class="rline matchdata"><?php echo match_info(22);?></td>
      <td class="goto"></td>
      <td class="fighter "><?php echo match_winner(22); ?></td>
    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(9,1); ?></td>
      <td></td>
      <td></td>

      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline matchdata"><?php echo match_info(9);?></td>
      <td class="goto"></td>

      <td class="rline fighter"><?php echo match_fighter(21,1); ?></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(9,2); ?></td>

      <td></td>
      <td class="rline"></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td></td>

      <td></td>
      <td class="rline matchdata"><?php echo match_info(21);?></td>
      <td class="goto"></td>
      <td class="rline fighter "><?php echo match_fighter(22,2); ?></td>
      <td></td>
      <td></td>
    </tr>
    <tr>

      <td class="rline fighter"><?php echo match_fighter(10,1); ?></td>
      <td></td>
      <td class="rline"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>

    <tr>
      <td class="rline matchdata"><?php echo match_info(10);?></td>
      <td class="goto"></td>
      <td class="rline fighter"><?php echo match_fighter(21,2); ?></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>

    </tr>
    <tr>
      <td class="rline fighter"><?php echo match_fighter(10,2); ?></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>

      <td></td>
    </tr>
  </tbody>
</table>

