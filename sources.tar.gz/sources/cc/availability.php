<?php $tz = -5;
$atz = abs($tz);
$tzs = 'UTC'. ($tz<0 ? '-' : '+') . ($atz<10 ? '0' : '').$atz.'00';
$days = array();
for($i = 20100222; $i <=20100228; $i++)
{
	$t = strtotime($i);
	$days[] = array(date('D, j M',$t), $i, $t);
}

?>
<html>
<head>
<link href="style.css" type="text/css" rel="stylesheet" rev="stylesheet">
</head>
<body>
<div>
<p class="gameinfo">Game: 2vs2 TKTF Group A, Team 1 (Drakas, <b>LiFe</b>) vs. Team 2 (tipper, jamz)</p>
<p>Week: <?php echo $days[0][0]; ?> - <?php echo $days[count($days)-1][0]; ?></p>
<p>Your timezone: <?php echo $tzs; ?></p>
<form>
<h2>Arrangements</h2>
<h3>Set your map choices</h3>
<dl>
<dt>Your first map</dt>
<dd><select name="map1"><option value="ac_elevation">ac_elevation</option><option value="ac_gothic">ac_gothic</option></select></dd>
<dt>Last map (only if you lose the second game)</dt>
<dd><select name="map1"><option value="ac_elevation">ac_elevation</option><option value="ac_gothic">ac_gothic</option></select></dd>
</dl>
<h3>Set your own availability times</h3>
<p>Ideally, allocate two hours of your time in one group. You will be playing three 15 minute games and some players might want to have breaks in-between.</p>
<p>The best times (ones that everyone can make) will be chosen by the administrators unless there are extra preferences which you may express in the comment form.</p>
<p>No more changes may be made to this form on the Friday before the week of playing.</p>
<table>
<tr><th>Day</th></tr>
<tr><th>UTC+0000</th><?php for($i =0; $i < 24;$i++) { ?><th><?php echo ($i<10 ? '0' : '').$i; ?></th><?php } ?></tr>
<tr><th style="text-decoration:underline"><?php echo $tzs; ?></th><?php for($i =0; $i < 24;$i++) { $h = $i+$tz; ?><th><?php
if ( $h < 0 ) { $h+=24;$prev = true; } else { $prev=false; }
echo ($h<10 ? '0' : '').$h;
if ( $prev ) { echo "*"; }
?></th><?php } ?></tr>
<?php foreach($days as $day) {
	?>
<tr>
<th><?php echo $day[0]; ?></th>
<?php for($i = 0; $i < 24; $i++)
{
	$iz = ($i<10 ? "0" : "").$i;
	?>
	<td><input type="checkbox" name="<?php echo $day[1]."_".$iz;?>" value="1"></td>
	<?php
}
?>
</tr>
	
	<?php } ?>
</table>
<p class="comment">* means the previous day</p>
<input type="submit" value="Submit">
</form>
<div>
<h2>Pre/post-match commentary</h2>
<form><textarea name="comment"></textarea>
<input type="submit" value="Comment">
</form>
<dl>
<dt>Drakas, 5th March 2010</dt>
<dd>Sure. You may Mumble/TS on our servers if you'd like.</dd>
<dt>tipper, 5th March 2010</dt>
<dd>Meet on IRC before we begin</dd>
</dl>
</div>
<form>
<h2>Games finished?</h2>
<h3>Results</h3>
<table>
<tr><th>Game</th><th>Team 1</th><th>Team 2</th><th>Screenshot</th><th>Demo</th></tr>
<tr><th>#1</th><td><input type="text" name="gs_11"></td><td><input type="text" name="gs_12"></td><td><input type="file" name="scr_1"></td><td><input type="file" name="dmo_1"></td></tr>
<tr><th>#2</th><td><input type="text" name="gs_21"></td><td><input type="text" name="gs_22"></td><td><input type="file" name="scr_2"></td><td><input type="file" name="dmo_2"></td></tr>
<tr><th>#3</th><td><input type="text" name="gs_31"></td><td><input type="text" name="gs_32"></td><td><input type="file" name="scr_3"></td><td><input type="file" name="dmo_3"></td></tr>
</table>
<input type="submit" value="Submit">
</form>
</div>
</body>
</html>

